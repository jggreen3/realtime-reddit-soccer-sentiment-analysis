import json
import boto3
import base64
from comment_table import Comment


# Set environmental vars for dynamodb
dyn_resource = boto3.resource('dynamodb')
comment_table = Comment(dyn_resource=dyn_resource)
comment_table.exists('reddit_comment_data')

# Set environmental vars for sagemaker
sagemaker_runtime = boto3.client('sagemaker-runtime', region_name='us-west-1')
endpoint_name = 'huggingface-pytorch-inference-2024-08-13-17-04-51-738'

def lambda_handler(event, context):

    for record in event['Records']:
        try:
            print(f"Processed Kinesis Event - EventID: {record['eventID']}")

            # Decode the base64 encoded data from Kinesis
            decoded_data = base64.b64decode(record['kinesis']['data'])

            # Load the decoded json data
            record_data = json.loads(decoded_data)

            # Analyze and store body sentiment
            response = sagemaker_runtime.invoke_endpoint(
                EndpointName=endpoint_name, 
                ContentType='application/json',  # Set the content type,
                Body=(json.dumps({'text': decoded_data['body']})))

            
            decoded_response = json.loads(response['Body'].read().decode('utf-8'))

            record_data['label'] = decoded_response['label']
            record_data['score'] = decoded_response['score']

            comment_table.add_comment(data=record_data)
        except Exception as e:
            print(f"An error occurred {e}")
            raise e
    print(f"Successfully processed {len(event['Records'])} records.")
